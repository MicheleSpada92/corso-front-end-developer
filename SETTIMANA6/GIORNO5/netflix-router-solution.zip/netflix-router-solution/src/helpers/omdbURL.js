const OMDB_URL = "https://www.omdbapi.com/?apikey=[your-key-here]";

export default OMDB_URL;
