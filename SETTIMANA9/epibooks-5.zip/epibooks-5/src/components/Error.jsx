import { Alert } from 'react-bootstrap'

const Error = () => (
  <Alert variant="danger">Error - Did you use your auth headers?</Alert>
)

export default Error
